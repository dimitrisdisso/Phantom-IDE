# PHANTOM

PHANTOM is a desktop IDE that works like a hacker workstation. It runs as a small operating system of floating windows: editors, terminals, monitors, network tools, Git, databases, a debugger and security scanners. You arrange them however you like across four virtual workspaces.

Everything is real: shells run in a real PTY, monitors read live kernel data, Git uses your Git binary, the debugger speaks the Chrome DevTools Protocol to Node, and the audits run on your project locally. It needs no cloud services, AI APIs or API keys.

## Install & run

You need **Node.js 20.17+** and **git**. These are optional but recommended: `ripgrep` (fast search) and an OpenSSH client (`ssh`, which Windows 10/11 already includes).

```bash
npm install      # Electron, Monaco, xterm.js, node-pty…  (no git-hosted packages, no rebuild step)
npm start        # launch PHANTOM
npm run dev      # launch with DevTools detached
npm run test:backend   # exercise every backend service against your real OS (plain Node)
npm run dist     # build installers with electron-builder (fetched on demand via npx)
```

Terminals use **node-pty 1.1**, which is built on N-API. On **Windows and macOS** it installs from prebuilt binaries that work in Electron without a rebuild. On **Linux** it compiles once with the usual toolchain (`build-essential`, `python3`). If it can't install, PHANTOM still runs: Linux and macOS fall back to the system `script` utility, which gives a real PTY that can't resize live, and Windows falls back to plain pipes. The taskbar shows `pty:native` or `pty:bridge`.

If a previous `npm install` failed partway, delete `node_modules` and `package-lock.json` first.

For the intended look, install a programming font such as **JetBrains Mono**, Fira Code or Cascadia Code. PHANTOM picks the first one it finds.

## The window system

| Action | How |
|---|---|
| Move / raise | drag the title bar · click anywhere in a window |
| Resize | drag any edge or corner (live size readout) |
| Snap | drag to an edge (half), a corner (quarter) or the top (maximize). Hold **Alt** to disable snapping and magnets |
| Magnetic alignment | windows snap to each other's edges (cyan guides). Set the threshold in Settings |
| Keyboard snap | **Ctrl+Alt+←/→/↑/↓** (halves → quarters → maximize/minimize) |
| Always on top | pin button or title right-click (amber frame) |
| Minimize / maximize / close | title buttons · double-click title · middle-click title or taskbar to close |
| Multiple instances | every tool can be opened many times (Shift+click a dock icon, or "Duplicate window") |
| Workspaces | **Ctrl+Alt+1–4** switch · **Ctrl+Alt+Shift+1–4** move the focused window |
| Arrange | **Ctrl+Alt+T** tile · cascade · **Ctrl+Alt+D** show desktop · **Alt+`** cycle |
| Layouts | **Ctrl+Shift+L** saves every window on all workspaces, including open files, terminal folders and tool state. Restore from the LAYOUT menu, or use a preset (Dev station, Recon/ops, Debug bay, API lab, Security sweep, Architecture) |

The session (project, windows, positions, states) is saved automatically and restored on launch.

## Running programs (F5, like Visual Studio)

| Key | Action |
|---|---|
| **F5** | Start: debugs JavaScript files in the Debugger; any other language runs in the **Run** terminal. While debugging, F5 continues or pauses |
| **Ctrl+F5** | Start without debugging |
| **Shift+F5** | Stop (ends the debug session, or sends Ctrl+C to the Run terminal) |
| **Ctrl+Shift+F5** | Restart |
| **F10 / F11 / Shift+F11** | Step over / into / out (while paused) |

F5 saves every modified file first, then runs the file open in the active editor. It picks the command from the extension: Python, Node, TypeScript (via `tsx`), Go (`go run`, or `go run .` inside a module), Rust (`cargo run` inside a crate, otherwise `rustc`), C/C++ (`gcc`/`g++` then the binary), C# (`dotnet run --project` with the nearest `.csproj`, otherwise `dotnet run file.cs`), F#, Java, Kotlin, Ruby, PHP, Lua, Perl, R, Julia, Swift, Dart, Zig, Elixir, Haskell, Bash, PowerShell and batch. HTML opens in your browser. The compiler or interpreter has to be installed and on your PATH.

Programs run in a single reusable **Run** terminal, so input prompts (`input()`, `Console.ReadLine()`…) work, and the exit code is printed at the end. To make F5 always run the same thing, like a Visual Studio startup project, use **RUN → Set project run command…** (for example `npm run dev` or `dotnet run`). It's saved per project. The ▶ button in each editor's tab bar does the same, and right-clicking it shows the other options.

## Tools

- **Editor** (Monaco): tabs, split groups (Ctrl+\\, drag tabs between groups or windows), IntelliSense for JS/TS/JSON/CSS/HTML, word-based completion everywhere, shared models across all editor windows, external-change detection with conflict warning, breakpoints (gutter/F9), optional autosave.
- **Terminal** (xterm.js + node-pty): real shells, 256-colour/truecolor, scrollback search (Ctrl+Shift+F), clickable links, copy/paste (Ctrl+Shift+C/V). The working directory is tracked so layouts reopen terminals in the right folder.
- **Explorer**: lazy tree, git status colours, create/rename/duplicate/trash (to the system trash), open-with menus, keyboard navigation.
- **Search**: project-wide search powered by ripgrep (built-in fallback). Supports regex, case and whole-word options, include/exclude globs, and replace-all with confirmation.
- **Git**: stage, unstage, discard, commit/amend, inline diffs, side-by-side Monaco diff, ASCII graph log with commit inspection, branches/checkout, fetch, pull (ff-only), push (auto-sets upstream), stash.
- **Debugger**: Node.js via `--inspect-brk` and CDP. Breakpoints, continue/pause/step over/into/out (F5/F10/F11), call stack, lazily-expanded scopes, and evaluation in the selected frame.
- **Test Runner**: auto-detects jest, vitest, mocha, node:test, pytest, unittest, cargo and go. Shows a live pass/fail/skip count, failure list and run history, with an optional watch mode.
- **Build Monitor**: detects npm/pnpm/yarn scripts, Makefile targets, cargo, go, python and docker tasks. Runs several at once with timing, error/warning counts and stop/rerun.
- **API Tester**: all common methods, params↔URL sync, headers, JSON/text/form bodies, bearer/basic auth, `{{env}}` variables, history, saved requests, copy as cURL. Requests run from the main process, so CORS doesn't apply.
- **Database**: SQLite (native `node:sqlite`, `sql.js` fallback), PostgreSQL and MySQL/MariaDB. Schema browser, Monaco SQL editor with table/column completion, result grid, CSV/JSON copy. Destructive statements ask for confirmation, and passwords are never written to disk.
- **SSH**: profiles (port, identity file, ProxyJump, L/R/D forwards) plus import from `~/.ssh/config`. Sessions run the system OpenSSH client in a PTY, so your keys, agent and known_hosts apply.
- **System Monitor**: total and per-core CPU, memory/swap, disk I/O, network throughput, filesystems, load, uptime, temperature, top processes.
- **Network**: per-interface traffic graphs, every socket with its owning process, listening ports (one click to open them in the API tester or probe them), interfaces.
- **Processes**: live CPU% (computed from /proc deltas on Linux), sortable, filterable, tree view, details (exe, cwd, fds, I/O), signals with confirmation.
- **Event Stream**: one live feed of file changes, Git state, process spawn/exit, ports opening and closing, PTY sessions, task results, debugger, security and resource-pressure events.
- **Logs**: tail -f any file (handles rotation) or PHANTOM's own log, with level colouring, filter/regex and follow mode.
- **Security Audit**: npm/pnpm audit, pip-audit, cargo audit and govulncheck when installed; a committed-secret scanner (AWS, GitHub, Slack, Stripe, private keys, JWTs, DB URLs…, with masked previews); and config checks for env files not ignored or committed, curl-pipe-sh scripts, unpinned or git dependencies, missing lockfiles, root containers, world-writable files and stray key material. Results are graded A–F.
- **Architecture**: a force-directed import graph for JS/TS (including tsconfig path aliases), Python, Go, Rust and CSS. Directory clustering, cycle detection (Tarjan SCC), most-imported/most-dependent lists, optional external packages. Double-click a module to open it.
- **Markdown / JSON viewers**: live markdown preview (sanitised with DOMPurify, follows unsaved edits) and a collapsible JSON tree with path copy, filtering and JSON Lines support.

Global keys: **F5** run · **Ctrl+Shift+P** command palette · **Ctrl+P** go to file (`file:line`) · **Ctrl+O** open folder · **Ctrl+`** terminal · **Ctrl+Shift+F/E/G** search/explorer/git · **Ctrl+,** settings · **Ctrl+Shift+W** close window · **F11** fullscreen.

Themes: PHANTOM, FSOCIETY, E CORP, AMBER CRT, DARK ARMY, ICEBREAKER, GHOST. You can also set a custom accent, glow intensity, scanlines and grid.

## Architecture

```
main/
  main.js          Electron bootstrap: app:// protocol, CSP, hardened session, IPC wiring
  preload.js       sandboxed contextBridge: window.phantom.invoke / on (channel allowlist)
  registry.js      builds the backend core and loads services
  util.js          exec/walk/which helpers (no Electron imports)
  services/*.js    one module per domain: fs, watch, pty, sys, proc, net, git, search, http,
                   db, ssh, audit, tasks, debug, arch, logs, events, store, app
renderer/
  index.html, css/ base · window manager · tool styles
  js/core/         api (bridge, shared pollers, telemetry), wm (window manager), shell (chrome,
                   palette, keys, layouts), docs (Monaco models, breakpoints), settings (themes),
                   project, ui (modals/menus/toasts), graph (canvas plots), dom
  js/apps/*.js     one module per tool: { id, title, icon, size, create(win, state) → instance }
tools/
  backend-test.js  integration tests for every service (runs in plain Node)
  devbridge.js     dev harness: serves the renderer over HTTP with the real backend (for UI testing)
```

Adding a tool means writing one file in `renderer/js/apps/` and registering it in `main.js` (and optionally the dock). A tool's `instance` can implement `serialize`, `apply`, `onResize`, `onShow`, `onFocus`, `canClose` and `destroy`. The window manager handles persistence, instances and workspaces.

**Security model.** The renderer runs with `contextIsolation`, `sandbox: true` and `nodeIntegration: false`. It is served only from the `app://` scheme, with path-traversal checks, a strict CSP (no remote scripts, no eval), navigation blocked and new windows denied. IPC handlers accept calls only from PHANTOM's own origin and validate their inputs. Git refs and SSH hosts/users are validated against option injection. Commands use `execFile` without a shell; the exception is user-authored build tasks, which run in a shell just as they would in a terminal. Process signals refuse PHANTOM itself and PID ≤ 1. Port probes are limited to loopback. Deletes go to the system trash. Database passwords and API auth values are never persisted.

**Performance.** All monitors share pollers, so one backend sample serves every window. Polling pauses for hidden or minimised windows and background workspaces. Backend snapshots are cached and de-duplicated. On Linux the file watcher skips `node_modules`, `.git` and build output. Terminal output is batched, and Monaco models are shared and reference-counted.
